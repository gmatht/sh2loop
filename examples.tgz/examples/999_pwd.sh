basename `pwd`
