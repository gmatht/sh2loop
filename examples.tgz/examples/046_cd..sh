cd ..
ls
